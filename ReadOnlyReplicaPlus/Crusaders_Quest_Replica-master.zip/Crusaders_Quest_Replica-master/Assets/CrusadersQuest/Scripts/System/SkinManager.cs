﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace CrusadersQuestReplica
{
    public class SkinManager : MonoBehaviour
    {
        [SerializeField]
        [HideInInspector]
        List<Skin> m_Skins;
    }
}
