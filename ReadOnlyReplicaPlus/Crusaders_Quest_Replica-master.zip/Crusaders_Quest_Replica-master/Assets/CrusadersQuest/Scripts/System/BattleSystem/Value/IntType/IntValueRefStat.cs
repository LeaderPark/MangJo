﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrusadersQuestReplica
{
    public class IntValueRefStat : IntValue
    {
        public override int GetValue()
        {

            return base.GetValue();
        }
    }
}