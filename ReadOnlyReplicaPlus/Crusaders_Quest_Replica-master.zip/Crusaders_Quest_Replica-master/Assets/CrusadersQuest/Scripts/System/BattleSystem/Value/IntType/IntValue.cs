﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace CrusadersQuestReplica
{
    public class IntValue:Value
    {
        public virtual int GetValue()
        {
            return 0;
        }
    }
}