﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrusadersQuestReplica
{
    public class UnitValue : Value
    {
        public virtual Unit GetValue()
        {
            return null;
        }
    }
}