﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace CrusadersQuestReplica
{
    [Serializable]
    public class DamageEffect : Effect
    {
        public override void Adjust(UnitValue caster, UnitValue target)
        {

            base.Adjust(caster, target);
        }

    }
}
