﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;

public class FloatEvent : UnityEvent<float>
{

}
