﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScript : MonoBehaviour
{
    private void OnMouseDown()
    {
        Debug.Log(1);
    }

}
