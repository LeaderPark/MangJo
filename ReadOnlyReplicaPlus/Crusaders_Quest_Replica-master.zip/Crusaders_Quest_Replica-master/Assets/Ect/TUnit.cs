﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TUnit : MonoBehaviour
{
    public float stat = 0;
    public float GetStat()
    {
        return stat;
    }
}
