﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloatV : V
{
    public virtual float ReturnValue() { return 0; }
}
