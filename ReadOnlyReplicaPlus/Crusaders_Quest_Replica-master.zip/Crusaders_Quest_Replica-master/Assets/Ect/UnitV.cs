﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitV : V
{
    public virtual TUnit ReturnValue() { return null; }
}
