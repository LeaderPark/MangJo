﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestMain : MonoBehaviour
{
    public FloatV floatV;
	// Use this for initialization
	void Start ()
    {
        Debug.Log(floatV.ReturnValue());
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
