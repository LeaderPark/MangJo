﻿using System.Collections;
using System.Collections.Generic;

enum FadeStep
{
    IN,
    IDLE,
    OUT,
    DONE,
}